Set-Location -LiteralPath $PSScriptRoot
$nodeCommand=Get-Command node -ErrorAction SilentlyContinue
$nodePath=if($nodeCommand){$nodeCommand.Source}else{Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'}
if(-not(Test-Path -LiteralPath $nodePath)){throw 'Install Node.js 24+ first.'}
$ngrokCommand=Get-Command ngrok -ErrorAction SilentlyContinue
$ngrokPath=if($ngrokCommand){$ngrokCommand.Source}else{Join-Path $PSScriptRoot '../../work/tools/ngrok/ngrok.exe'}
if(-not(Test-Path -LiteralPath $ngrokPath)){throw 'Install ngrok from https://ngrok.com/download/windows and run this script again.'}
try{Invoke-WebRequest http://127.0.0.1:8765/api/config -UseBasicParsing -TimeoutSec 3 | Out-Null}catch{throw 'Start yautomation with Start-Yautomation.ps1 before opening the tunnel.'}
try{Invoke-WebRequest http://127.0.0.1:5202/api/config -UseBasicParsing -TimeoutSec 3 | Out-Null}catch{
  Start-Process -FilePath $nodePath -ArgumentList 'server/public-preview.mjs' -WorkingDirectory $PSScriptRoot -WindowStyle Hidden
  Start-Sleep -Seconds 1
}
if(-not $env:NGROK_AUTHTOKEN){
  Write-Host 'Sign in at https://dashboard.ngrok.com/get-started/your-authtoken'
  Write-Host 'Paste your token only at the private prompt below. It will not be saved or printed.'
  $privateToken=Read-Host 'ngrok authtoken' -AsSecureString
  $env:NGROK_AUTHTOKEN=[System.Net.NetworkCredential]::new('', $privateToken).Password
}
try{& $ngrokPath http 5202}finally{Remove-Item Env:NGROK_AUTHTOKEN -ErrorAction SilentlyContinue}
