# Reporting security issues
Do not publish credentials or private user data in an issue. Contact the operator of the installation privately. This source distribution has no configured maintainer security mailbox; deployments should add their own contact. Review HTTPS, OAuth settings, backup handling and retention policy before exposing the backend publicly.
