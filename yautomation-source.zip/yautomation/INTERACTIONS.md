# Pages and interaction map

The app uses distinct URL-addressable hash routes, with browser Back/Forward support, on the same Node-hosted origin. They are actual separate application screens, not separate server processes.

| Action | Destination or popup |
| --- | --- |
| Sign in / Connect Google | #/signin; Google handoff popup when OAuth is ready |
| Google connection completed | #/welcome, verified session required |
| AI key settings / Manage account | #/connections; key-save receipt popup |
| New story / Make a video | #/new |
| My projects | #/projects with real loading, empty, unauthorized and error states |
| Continue to production | #/submit prerequisite/loading/error page, then #/job/<id> after verified enqueue |
| View a project | #/job/<id>, authenticated real status only |
| Installation setup | #/setup with recheck and callback-copy receipt popups |
| Import script | File chooser popup, then preview/replace popup |
| Download brief | Project-specific export summary popup |
| First Cup / sample | #/example or draft replacement popup |
| Open-source kit | #/source, then source download popup |
| How it works | #/workflow with separate stage-explanation popups |
| FAQ questions | Individual answer popups |
| Clear local draft | Clear/keep confirmation popup |
| Sign out / Disconnect Google | Separate account-action popups |
| Close / Cancel | Dismisses the current popup without acting |

Dropdowns, inputs and the job authorization checkbox retain their normal native interactions. Download confirmations request a browser download; they do not claim the file has been saved. Refreshing #/submit does not submit another paid job. Unknown routes display a recovery page.

Google OAuth remains unconfigured on the current local installation. Its unavailable state is shown explicitly; success and progress screens do not fabricate account connections or jobs. Live provider generation was not tested during this UI change.
