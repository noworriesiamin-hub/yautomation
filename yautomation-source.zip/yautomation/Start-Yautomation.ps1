Set-Location -LiteralPath $PSScriptRoot
$runtime=Get-Command node -ErrorAction SilentlyContinue
if($runtime){$nodePath=$runtime.Source}else{$nodePath=Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'}
if(-not(Test-Path -LiteralPath $nodePath)){throw 'Install Node.js 24 or later, then run this script again.'}
& $nodePath setup.mjs
& $nodePath server/index.mjs
