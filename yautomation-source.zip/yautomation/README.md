# yautomation by yash

An MIT-licensed, self-hostable script-to-video agent with a red-and-ivory interactive landing page. Each creator uses their own Google identity, Drive, Gmail and provider API keys. There is no shared owner email or shared Flow browser session.

## What is implemented

- Responsive illustrated paper-and-film design, expandable workflow, example loader, script import, local drafts, brief downloads, project tabs and key settings.
- Google authorization-code OAuth with PKCE, state binding and verified identity. HTTP-only sessions and CSRF protection for writes.
- Per-user project queries and AES-256-GCM encrypted provider keys and Google refresh tokens. Ciphertexts are bound to their user ID.
- SQLite durable queue, one active project per user and one worker in this process. A restart marks interrupted work for operator attention instead of spending again automatically.
- OpenAI script/storyboard and image requests, Google Veo image-to-video REST requests, FFmpeg assembly and full-decode verification, resumable Drive upload with size readback, and Gmail self-delivery.
- No routine creative-stage approval gates. One job-start authorization covers paid generation and delivery within the displayed reservation.
- Docker configuration, test suite and MIT source distribution.

## Current verification and limitations

Core, HTTP isolation/security and an offline worker simulation pass. The browser example loader and preview-mode generation block were checked. The live OAuth, paid AI model requests and delivery pipeline have NOT been exercised from this standalone application. The earlier First Cup delivery was performed by Codex connectors, not by this server.

The preview intentionally has no OAuth client, real provider keys or enabled worker. It cannot create live videos until configured. This is an initial implementation, not an audited public production service.

The worker uses a host-configured Veo-compatible model, 8-second source clips, OpenAI image reference prompts and straight-cut assembly. It does not dynamically browse Flow's model menu. It defaults to natural ambience without narration, music or captions. Image identities depend on the generated results and shared continuity prompts; no automatic visual-quality guarantee is made.

Flow credits and consumer ChatGPT subscriptions do not fund these API requests. API billing belongs to each user's providers. The host's configured pricing reservation is NOT a provider-enforced dollar cap or a live quote; configure conservative current rates and set provider-side budgets. No automatic generation retries occur. Interrupted submissions need operator review of saved checkpoints and provider history before resubmission.

## Quick start (Node.js 24+)

```sh
node setup.mjs
# Configure Google OAuth client ID and secret in the generated private .env.
# Fill the Google OAuth client settings and model/cost settings described below.
npm test
npm start
```

On Windows use `Copy-Item .env.example .env`. Install FFmpeg/FFprobe or set their absolute executable paths. The default renderer uses libx264; an FFmpeg build without it needs an available H.264 encoder in VIDEO_ENCODER. The source has no npm runtime dependencies; it uses Node's built-in SQLite, crypto, HTTP and fetch.

Open the PUBLIC_ORIGIN you configured, default http://localhost:8787. The static files can also be served independently as a brief-builder preview, but login and production require this backend on the same origin.

## Google setup

1. Create a Google Cloud project and enable Google Drive API and Gmail API.
2. Configure an external OAuth consent screen with your real application identity, support/contact details and policy URLs. Add your testing users while testing. Complete any required verification before general availability.
3. Create a Web application OAuth client. Register exactly `https://YOUR-DOMAIN/auth/google/callback` for production, or `http://localhost:8787/auth/google/callback` locally.
4. Configure GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET and PUBLIC_ORIGIN on the server. Never put these secrets in dist/.
5. The app requests openid/email/profile, drive.file and gmail.send. Users explicitly grant these scopes. Uploaded files remain private; email is sent only to the verified Google identity. The app does not accept an arbitrary mail address as authority to access an account.

Reference: https://developers.google.com/identity/protocols/oauth2/web-server

## AI setup and job execution

Configure OPENAI_TEXT_MODEL, OPENAI_IMAGE_MODEL and GOOGLE_VIDEO_MODEL with compatible models available in your provider projects. This adapter expects OpenAI Responses JSON-object output and Image API base64 PNG output, and the Google Veo predictLongRunning image-to-video schema. Model availability and supported parameters must be checked for your accounts before enabling the worker.

Set conservative RESERVE_TEXT_USD (one bounded planning call), RESERVE_IMAGE_USD (one image), and RESERVE_VIDEO_SECOND_USD (8 source seconds per scene). Keep ENABLE_WORKER=false until all settings and billing limits are checked. Set it to true to allow paid jobs. The queue rejects insufficient job reservations before submitting.

Users then sign in, save their own OpenAI and Google AI API keys through connection settings, enter a script and maximum reservation, and start one job. Keys are sent over the app's connection and stored encrypted. Serve production over HTTPS. The worker processes planning → images → video → editing → uploading → emailing. Successful jobs show a real Drive link and retain the sent-message receipt on the server.

References:
- https://developers.openai.com/api/docs/guides/text
- https://developers.openai.com/api/docs/guides/image-generation
- https://ai.google.dev/gemini-api/docs/veo

## Deploy your own installation

```sh
docker compose up --build -d
```

Use one replica and a persistent data volume. Put the container behind an HTTPS reverse proxy on your own domain, set PUBLIC_ORIGIN to that exact origin, and update the OAuth redirect URI. Do not expose the SQLite database or .data directory through the reverse proxy. Back up the encryption key separately from the database; losing it makes saved credentials unreadable. A compromised host can still access decrypted credentials while running.

The current SQLite/single-worker architecture is intended for a small deployment. Horizontal scaling requires atomic queue claims and a shared durable database/object store. Jobs and media remain in DATA_DIR until the operator removes them under its retention policy. Disconnecting Google revokes access and removes saved credentials, but preserves project records and local rendered files; make that policy clear to your users.

Before broad public launch, run real OAuth and paid-provider smoke tests, review failure recovery, add monitoring and a host retention policy, and review operational security. OAuth/hosting/API accounts cannot be provisioned merely from the source archive.

## Source and publishing status

The code is MIT-licensed and downloadable as source.zip. No public GitHub repository was created. The archive excludes credentials, databases, media jobs, Sites identity, and .git metadata.

The static Sites registration remains appgprj_6acdced039248191915481dc435156f4; it is not a verified public deployment. The earlier source-publishing helper was rejected by the automatic approval policy when passing its repository credential through stdin. Do not recreate that Site or claim its expected URL is live. Sites static hosting can serve this landing page, but the Node/FFmpeg production backend requires a compatible server/container host.

## Connection setup troubleshooting
The page must be served by the Node app, not python -m http.server. The setup banner now reports backend, OAuth and worker state; unavailable connection/creation buttons open a visible setup dialog. See dist/setup.md for the step-by-step Google setup and Start-Yautomation.ps1 to launch locally. The active local callback is http://127.0.0.1:8765/auth/google/callback. Credentials have not been supplied; Google sign-in remains unavailable until the owner finishes that step.

## Dedicated pages and popups
See INTERACTIONS.md for the complete button-to-page map. Main actions now have URL-addressable screens for sign-in, connection success, account settings, new stories, project history, production status, setup, examples and open source. Imports, exports, callback copying, FAQ answers and account actions use focused native dialogs. Browser refresh never automatically repeats a paid submission. OAuth returns to the verified welcome screen, and failures return to the sign-in error state.

## Temporary ngrok public preview
Start the app on 8765, then run Start-PublicPreview.ps1 in PowerShell. It forwards port 5202 to this app and invokes ngrok http 5202. The launcher prompts privately for an account authtoken and does not save or print it. Download/install ngrok from its official website if it is not on PATH. Ngrok requires an authenticated account; no public URL exists before successful authentication. Keep the app, forwarding process and tunnel running while sharing. To test Google OAuth through the public domain, set PUBLIC_ORIGIN to the real ngrok HTTPS URL, register that exact /auth/google/callback in Google Cloud, and restart the app.

### Windows execution policy
If PowerShell blocks .ps1 files, use Start-PublicPreview.cmd directly from Command Prompt or double-click it. It uses Node to start the app/forwarder and request an ngrok token privately. No execution-policy change is required.
