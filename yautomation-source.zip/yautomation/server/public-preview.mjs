import http from 'node:http';
// Only this app's local backend is forwarded. The ngrok inspector is not exposed.
const upstream='127.0.0.1',port=8765;
http.createServer((req,res)=>{const proxy=http.request({hostname:upstream,port,path:req.url,method:req.method,headers:{...req.headers,host:`${upstream}:${port}`}},r=>{res.writeHead(r.statusCode,r.headers);r.pipe(res)});proxy.on('error',()=>{if(!res.headersSent)res.writeHead(503,{'Content-Type':'text/plain'});res.end('yautomation backend is unavailable. Start the app on port 8765 first.')});req.on('aborted',()=>proxy.destroy());req.pipe(proxy)}).listen(5202,'127.0.0.1',()=>console.log('yautomation tunnel target ready: http://127.0.0.1:5202 → http://127.0.0.1:8765'));
