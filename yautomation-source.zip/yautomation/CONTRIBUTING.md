# Contributing
Use Node.js 24+, run npm test and npm run check. Keep private data in DATA_DIR outside dist/. Do not add real credentials or provider-generated job assets to source control. Add tests for authorization boundaries and uncertain-submission recovery when changing the worker. Paid-provider smoke tests are opt-in and must never run in the default test suite.
