@echo off
setlocal
cd /d "%~dp0"
set "Y_AUTOMATION_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if exist "%Y_AUTOMATION_NODE%" goto run
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 24 or later is required. Please install Node.js first.
  pause
  exit /b 1
)
set "Y_AUTOMATION_NODE=node"
:run
"%Y_AUTOMATION_NODE%" server\tunnel-launcher.mjs
if errorlevel 1 pause
endlocal
